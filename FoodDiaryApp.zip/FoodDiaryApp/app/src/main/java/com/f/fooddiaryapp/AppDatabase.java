package com.f.fooddiaryapp;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

// класс отвечающий за параметры базы данных
@Database(entities = {Note.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase instance;

    public abstract NoteDao noteDao();

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void> {
        private NoteDao noteDao;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        private PopulateDbAsyncTask(@NonNull AppDatabase db) {
            noteDao = db.noteDao();
        }

        // метод для предзагрзуки набора данных в БД
        @Override
        protected Void doInBackground(Void... voids) {
            noteDao.insert(new Note("01.12.2022", "08:00", "Овсянка", 100, 100, 10, 20, "Завтрак"));
            noteDao.insert(new Note("01.12.2022", "14:00", "Паста болоньезе", 1200, 500, 200, 200, "Обед"));
            noteDao.insert(new Note("01.12.2022", "20:00", "Пицца пеперони", 1000, 900, 300, 200, "Ужин"));
            return null;
        }
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            new PopulateDbAsyncTask(instance).execute();
            super.onCreate(db);
        }
    };

    // метод для получения экземпляра базы данных
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "fooddiary_app_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }
}

