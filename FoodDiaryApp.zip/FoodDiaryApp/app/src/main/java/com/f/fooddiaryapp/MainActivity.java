package com.f.fooddiaryapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Note> notesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Дневник питания");
        // вызов функции установки ярлыка на рабочий стол только при первом запуске приложения
        boolean firstRun = getSharedPreferences("preferences", MODE_PRIVATE).getBoolean("firstrun", true);
        if (firstRun) {
            getSharedPreferences("preferences", MODE_PRIVATE).edit().putBoolean("firstrun", false).apply();
            installShortcut();
        }
        // вызов функции загрзуки списка записей и вывод их на экране
        loadNotesAndShow();

        // кнопка добавления новой записи
        FloatingActionButton floatingActionButton = findViewById(R.id.fab_note_add);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
                startActivity(intent);
            }
        });
    }

    // функция для установки ярлыка на рабочий стол
    private void installShortcut() {
        Intent shortCutIntent = new Intent(getApplicationContext(), MainActivity.class);
        shortCutIntent.setAction(Intent.ACTION_MAIN);
        Intent addIntent = new Intent();
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortCutIntent);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, "Дневник питиания");
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                Intent.ShortcutIconResource.fromContext(getApplicationContext(), R.mipmap.ic_launcher));
        addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        addIntent.putExtra("duplicate", false);
        getApplicationContext().sendBroadcast(addIntent);
    }

    // метод для загрузки списка записей из БД и их вывода
    private void loadNotesAndShow() {
        AppDatabase database = AppDatabase.getInstance(getApplication());
        NoteDao noteDao = database.noteDao();

        notesList = new ArrayList<Note>();

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                notesList = noteDao.getAll();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showNotes();
                    }
                });
                if (notesList.size() == 0) {
                    loadNotesAndShow();
                }
            }
        });
    }

    // метод для вывода списка записей в Recyclerview
    private void showNotes() {
        RecyclerView rvNotes = findViewById(R.id.rv_notes);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this);
        NoteAdapter noteAdapter = new NoteAdapter(notesList);
        noteAdapter.setOnClickListener(new NoteAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Note note) {
                Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
                intent.putExtra("note", note);
                startActivity(intent);
            }
        });
        rvNotes.setAdapter(noteAdapter);
        rvNotes.setLayoutManager(linearLayoutManager);
        rvNotes.setHasFixedSize(true);
        rvNotes.setNestedScrollingEnabled(false);
    }

    // перегруженный метод для создания AppBar меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.app_bar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    // перегруженный метод вызываемый при выборе одного из пунктов AppBar menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_btn_main:
                return true;
            case R.id.menu_btn_add:
                Intent profileIntent = new Intent(MainActivity.this, AddEditNoteActivity.class);
                startActivity(profileIntent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}