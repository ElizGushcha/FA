package com.f.fooddiaryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEditNoteActivity extends AppCompatActivity {

    private EditText etDate;
    private EditText etTime;
    private EditText etProduct;
    private EditText etCalories;
    private EditText etCarb;
    private EditText etFat;
    private EditText etProteins;
    private EditText etText;

    private Note note;
    NoteDao noteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);

        etDate = findViewById(R.id.et_date);
        etTime = findViewById(R.id.et_time);
        etProduct = findViewById(R.id.et_product);
        etCalories = findViewById(R.id.et_calories);
        etCarb = findViewById(R.id.et_carb);
        etFat = findViewById(R.id.et_fat);
        etProteins = findViewById(R.id.et_proteins);
        etText = findViewById(R.id.et_text);
        Button btnSave = findViewById(R.id.btn_save);
        Button btnRemove = findViewById(R.id.btn_remove);

        note = getIntent().getParcelableExtra("note");
        AppDatabase database = AppDatabase.getInstance(getApplication());
        noteDao = database.noteDao();

        if (note != null) {
            setTitle("Изменение записи");
            etDate.setText(note.getDate());
            etTime.setText(note.getTime());
            etProduct.setText(note.getProduct());
            etCalories.setText(String.valueOf(note.getCalories()));
            etCarb.setText(String.valueOf(note.getCarbohydrates()));
            etFat.setText(String.valueOf(note.getFat()));
            etProteins.setText(String.valueOf(note.getProteins()));
            etText.setText(note.getText());
        } else {
            setTitle("Создание записи");
            btnRemove.setVisibility(View.GONE);
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveNote();
            }
        });

        btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeNote();
            }
        });
    }

    // метод сохранения записи
    private void saveNote() {
        try {
            String date = etDate.getText().toString();
            String time = etTime.getText().toString();
            String product = etProduct.getText().toString();
            String text = etText.getText().toString();
            if (date.equals("")||time.equals("")||product.equals("")||text.equals("")){
                throw new IllegalArgumentException("Все поля должны быть заполнены!");
            }
            int calories = Integer.parseInt(etCalories.getText().toString());
            int carbohydrates = Integer.parseInt(etCarb.getText().toString());
            int fat = Integer.parseInt(etFat.getText().toString());
            int proteins = Integer.parseInt(etProteins.getText().toString());

            // проверка строк даты и времени на соответстие нужному паттерну
            if (!date.matches("([0-9]{2}).([0-9]{2}).([0-9]{4})")){
                throw new IllegalArgumentException("Дата должна быть в формате dd.mm.yyyy!");
            }

            if (!time.matches("([0-9]{2}):([0-9]{2})")){
                throw new IllegalArgumentException("Время должно быть в формате hh:mm");
            }

            // сохранение данных объекта записи с обработкой исключительных ситуаций
            if (note != null) {
                note.setDate(date);
                note.setTime(time);
                note.setProduct(product);
                note.setCalories(calories);
                note.setCarbohydrates(carbohydrates);
                note.setFat(fat);
                note.setProteins(proteins);
                note.setText(text);
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        noteDao.update(note);
                        Intent intent = new Intent(AddEditNoteActivity.this, MainActivity.class);
                        startActivity(intent);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(AddEditNoteActivity.this, "Запись успешно изменена!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            } else {
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        noteDao.insert(new Note(date, time, product, calories, carbohydrates, fat, proteins, text));
                        Intent intent = new Intent(AddEditNoteActivity.this, MainActivity.class);
                        startActivity(intent);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(AddEditNoteActivity.this, "Запись успешно добавлена!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }
            // если в коде было вызвано исключение, выводим пользователю сообщение об этом
        } catch (NumberFormatException e){
            Toast.makeText(this, "Поля калорий, белкиов, жиров и углеводов должны быть заполнены целыми числами!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // метод удаления записи
    private void removeNote() {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                noteDao.delete(note);
                Intent intent = new Intent(AddEditNoteActivity.this, MainActivity.class);
                startActivity(intent);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(AddEditNoteActivity.this, "Запись успешно удалена!", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    // перегруженный метод для создания AppBar меню
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.app_bar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // перегруженный метод вызываемый при выборе одного из пунктов AppBar menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_btn_main:
                Intent intent = new Intent(AddEditNoteActivity.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_btn_add:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}