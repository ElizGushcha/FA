package com.f.fooddiaryapp;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Клласс-модель для записи дневника, реализует интерфейс parcelable
// для передачи в кчестве объекта между активити
@Entity(tableName = "notes_table")
public class Note implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String date;

    private String time;

    private String product;

    private int calories;

    // углеводы
    private int carbohydrates;

    // жиры
    private int fat;

    // белки
    private int proteins;

    private String text;

    public Note(String date, String time, String product, int calories, int carbohydrates, int fat, int proteins, String text) {
        this.date = date;
        this.time = time;
        this.product = product;
        this.calories = calories;
        this.carbohydrates = carbohydrates;
        this.fat = fat;
        this.proteins = proteins;
        this.text = text;
    }

    protected Note(Parcel in) {
        id = in.readInt();
        date = in.readString();
        time = in.readString();
        product = in.readString();
        calories = in.readInt();
        carbohydrates = in.readInt();
        fat = in.readInt();
        proteins = in.readInt();
        text = in.readString();
    }

    public static final Creator<Note> CREATOR = new Creator<Note>() {
        @Override
        public Note createFromParcel(Parcel in) {
            return new Note(in);
        }

        @Override
        public Note[] newArray(int size) {
            return new Note[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public int getCarbohydrates() {
        return carbohydrates;
    }

    public void setCarbohydrates(int carbohydrates) {
        this.carbohydrates = carbohydrates;
    }

    public int getFat() {
        return fat;
    }

    public void setFat(int fat) {
        this.fat = fat;
    }

    public int getProteins() {
        return proteins;
    }

    public void setProteins(int proteins) {
        this.proteins = proteins;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(date);
        parcel.writeString(time);
        parcel.writeString(product);
        parcel.writeInt(calories);
        parcel.writeInt(carbohydrates);
        parcel.writeInt(fat);
        parcel.writeInt(proteins);
        parcel.writeString(text);
    }
}
