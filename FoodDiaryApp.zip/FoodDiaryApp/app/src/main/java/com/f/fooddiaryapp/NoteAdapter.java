package com.f.fooddiaryapp;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// класс-адаптер для вывода объекта записи (note) в списке recyclerview
public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {

    private List<Note> noteList;
    private OnItemClickListener listener;

    public NoteAdapter(List<Note> noteList) {
        this.noteList = noteList;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.tvItemTitle.setText(note.getText());
        holder.tvItemProduct.setText(note.getProduct());
        holder.tvItemDateTime.setText(note.getDate() + " " + note.getTime());
        holder.tvItemCalories.setText("Калории: " + note.getCalories());
        holder.tvItemParams.setText("Белки: " + note.getProteins() + " Жиры: " + note.getFat() + " Углеводы: " + note.getCarbohydrates());
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItemTitle;
        TextView tvItemProduct;
        TextView tvItemDateTime;
        TextView tvItemCalories;
        TextView tvItemParams;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tvItemTitle = itemView.findViewById(R.id.tv_note_item_title);
            this.tvItemProduct = itemView.findViewById(R.id.tv_note_item_product);
            this.tvItemDateTime = itemView.findViewById(R.id.tv_note_item_date_time);
            this.tvItemCalories = itemView.findViewById(R.id.tv_note_item_calories);
            this.tvItemParams = itemView.findViewById(R.id.tv_note_item_params);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(noteList.get(position));
                    }
                }
            });
        }
    }

    // интерфейс для обработки нажатия на элемент списка
    public interface OnItemClickListener {
        void onItemClick(Note note);
    }

    // метод для обработки нажатия на элемент списка
    public void setOnClickListener(NoteAdapter.OnItemClickListener listener) {
        this.listener = listener;
    }
}
